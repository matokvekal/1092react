import React from 'react'

const Counter = () => {
  return (
    <div>Counter</div>
  )
}

export default Counter